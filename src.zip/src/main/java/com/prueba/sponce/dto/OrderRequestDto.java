package com.prueba.sponce.dto;

import lombok.Data;

import java.util.List;

@Data
public class OrderRequestDto {
    private ClientDto client;
    private OrderDetailDto orderDetail;
    private List<Long> productIds;
}
