package com.prueba.sponce.client;

import com.prueba.sponce.dto.ProductDto;
import com.prueba.sponce.exception.ProductNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

@Component
@RequiredArgsConstructor
public class ProductSyncClient {

    private final WebClient.Builder webClientBuilder;

    @Value("${fake-store.base-url}")
    private String baseUrl;

    public ProductDto getProductById(Long id) {
        try {
            return webClientBuilder.baseUrl(baseUrl)
                    .build()
                    .get()
                    .uri("/products/{id}", id)
                    .retrieve()
                    .bodyToMono(ProductDto.class)
                    .block(); // Solo aquí usamos block, fuera del flujo WebFlux
        } catch (WebClientResponseException.NotFound ex) {
            throw new ProductNotFoundException(id);
        }
    }
}
